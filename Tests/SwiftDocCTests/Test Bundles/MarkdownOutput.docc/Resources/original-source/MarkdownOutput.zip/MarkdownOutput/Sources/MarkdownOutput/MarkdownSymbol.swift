/// A basic symbol to test markdown output.
///
/// This is the overview of the symbol.
public struct MarkdownSymbol {
    public let name: String
    
    @available(iOS, introduced: 1.0, deprecated: 4.0, message: "Don't be so formal")
    @available(macOS, introduced: 2.0, deprecated: 4.0, message: "Don't be so formal")
    public let fullName: String
   
    @available(iOS, obsoleted: 5.0)
    public var otherName: String?
    
    public init(name: String) {
        self.name = name
        self.fullName = name
    }
}
