import Foundation

/// A basic symbol to test markdown output.
///
/// This is the overview of the symbol.
public struct MarkdownSymbol {
    public let name: String
    
    @available(iOS, introduced: 1.0, deprecated: 4.0, message: "Don't be so formal")
    @available(macOS, introduced: 2.0, deprecated: 4.0, message: "Don't be so formal")
    public let fullName: String
   
    @available(iOS, obsoleted: 5.0)
    public var otherName: String?
    
    public init(name: String) {
        self.name = name
        self.fullName = name
    }
}

/// This type conforms to multiple external protocols
public struct ExternalConformer: Codable, Identifiable, Hashable {
    public let id: String
}

/// This type demonstrates conformance in documentation
public enum LocalConformer: LocalProtocol {
    public func localMethod() {
        
    }
    
    case boo
}

/// This is a locally defined protocol to support the relationship test case
public protocol LocalProtocol {
    func localMethod()
}

/// This is a class to demonstrate inheritance in documentation
public class LocalSubclass: LocalSuperclass {
    
}

/// This is a class to demonstrate inheritance in symbol documentation
public class LocalSuperclass {
    
}
